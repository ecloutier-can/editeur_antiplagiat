/*
  SCORM 1.2 API Wrapper — Éditeur Anti-Plagiat v7
  Compatible Moodle 4.5
  
  Stratégie de sauvegarde :
  ┌──────────────────────────────────────────────────────┐
  │ TEXTE COMPLET  →  localStorage  (illimité, fiable)  │
  │ MÉTADONNÉES    →  cmi.suspend_data (4096 car. max)  │
  │ TEXTE BRUT     →  cmi.comments   (2000 car. aperçu) │
  └──────────────────────────────────────────────────────┘
  Le texte rédigé n'est JAMAIS tronqué.
*/
var SCORM = (function () {
  'use strict';
  var _api  = null;
  var _init = false;

  function findAPI(w) {
    var d = 0;
    while (!w.API && w.parent && w.parent !== w && d < 7) { d++; w = w.parent; }
    return w.API || null;
  }
  function api() {
    if (!_api) {
      _api = findAPI(window);
      if (!_api && window.opener) _api = findAPI(window.opener);
    }
    return _api;
  }
  function call(fn, args) {
    var a = api();
    if (!a) return null;
    try { return a[fn].apply(a, args || []); } catch (e) { return null; }
  }

  /* ── Clé localStorage ─────────────────────── */
  function lsKey(studentId) {
    return 'scorm_editor_' + (studentId || 'anon');
  }

  /* ── localStorage helpers ─────────────────── */
  function lsSet(key, val) {
    try { localStorage.setItem(key, val); return true; } catch(e) { return false; }
  }
  function lsGet(key) {
    try { return localStorage.getItem(key); } catch(e) { return null; }
  }
  function lsDel(key) {
    try { localStorage.removeItem(key); } catch(e) {}
  }

  return {
    init: function () {
      var r = call('LMSInitialize', ['']);
      _init = (r === 'true' || r === true);
      return _init;
    },
    get: function (k) {
      if (!_init) return '';
      var r = call('LMSGetValue', [k]);
      return r !== null ? String(r) : '';
    },
    set: function (k, v) {
      if (!_init) return false;
      var r = call('LMSSetValue', [k, String(v)]);
      return r === 'true' || r === true;
    },
    commit: function () { if (_init) call('LMSCommit', ['']); },
    finish: function () {
      if (!_init) return;
      call('LMSCommit', ['']);
      call('LMSFinish', ['']);
      _init = false;
    },
    getStudentName: function () { return this.get('cmi.core.student_name') || 'Étudiant'; },
    getStudentId:   function () { return this.get('cmi.core.student_id')   || ''; },

    /* ════════════════════════════════════════════
       SAVE — texte dans localStorage, métadonnées dans SCORM
    ════════════════════════════════════════════ */
    save: function (obj) {
      var studentId = this.getStudentId();

      /* 1. TEXTE COMPLET → localStorage (jamais tronqué) */
      var lsData = {
        v:       obj.v || 1,
        text:    obj.text || '',
        ts:      Date.now(),
        wc:      obj.wc || 0,
        submitted:  obj.submitted  || false,
        submitTime: obj.submitTime || null
      };
      lsSet(lsKey(studentId), JSON.stringify(lsData));

      /* 2. MÉTADONNÉES → cmi.suspend_data (sans le texte) */
      if (_init) {
        var meta = {
          v:          obj.v,
          log:        (obj.log || []).slice(-10),
          paste:      obj.paste      || 0,
          copy:       obj.copy       || 0,
          tabs:       obj.tabs       || 0,
          focus:      obj.focus      || 0,
          screenshots:obj.screenshots|| 0,
          absentMs:   obj.absentMs   || 0,
          lastIssues: (obj.lastIssues|| []).slice(0,5),
          submitted:  obj.submitted  || false,
          submitTime: obj.submitTime || null,
          wc:         obj.wc         || 0,
          lsKey:      lsKey(studentId) /* pointeur vers localStorage */
        };
        var json = JSON.stringify(meta);
        /* Garantie : ne dépasse jamais 4096 car. */
        if (json.length > 3900) {
          meta.log        = meta.log.slice(-5);
          meta.lastIssues = [];
          json = JSON.stringify(meta);
        }
        this.set('cmi.suspend_data', json);

        /* 3. Aperçu texte brut → cmi.comments (2000 car. pour rapports Moodle) */
        var plain = (obj.text || '').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
        this.set('cmi.comments', plain.substring(0, 2000));
        this.commit();
      }
    },

    /* ════════════════════════════════════════════
       LOAD — fusionne localStorage + SCORM
       Priorité : localStorage si plus récent
    ════════════════════════════════════════════ */
    load: function () {
      var studentId = this.getStudentId();
      var lsRaw  = lsGet(lsKey(studentId));
      var lsData = null;
      if (lsRaw) {
        try { lsData = JSON.parse(lsRaw); } catch(e) {}
      }

      /* Métadonnées depuis SCORM */
      var meta = null;
      if (_init) {
        var raw = this.get('cmi.suspend_data');
        if (raw && raw.length > 2) {
          try { meta = JSON.parse(raw); } catch(e) {}
        }
      }

      if (!lsData && !meta) return null;

      /* Fusionner : texte depuis localStorage, compteurs depuis SCORM */
      var result = {};
      if (meta)   Object.assign(result, meta);
      if (lsData) {
        result.text      = lsData.text;      /* texte complet depuis localStorage */
        result.submitted = lsData.submitted || result.submitted;
        result.submitTime= lsData.submitTime || result.submitTime;
        result.wc        = lsData.wc        || result.wc;
        /* Prendre la version la plus récente pour submitted */
        if (lsData.submitted) {
          result.submitted  = true;
          result.submitTime = lsData.submitTime;
        }
      }
      return result;
    },

    /* Effacer localStorage après soumission confirmée */
    clearLocal: function() {
      var studentId = this.getStudentId();
      /* On garde localStorage même après soumission — 
         l'enseignant peut avoir besoin de récupérer */
    },

    /* Vérifie si localStorage a du contenu plus récent que SCORM */
    hasLocalBackup: function() {
      var studentId = this.getStudentId();
      var raw = lsGet(lsKey(studentId));
      if (!raw) return false;
      try {
        var d = JSON.parse(raw);
        return d && d.text && d.text.length > 0;
      } catch(e) { return false; }
    },

    submit: function (score) {
      if (!_init) return;
      this.set('cmi.core.score.raw', score || 100);
      this.set('cmi.core.score.min', 0);
      this.set('cmi.core.score.max', 100);
      this.set('cmi.core.lesson_status', 'passed');
      this.set('cmi.core.exit', '');
      this.commit();
    },

    setIncomplete: function () {
      if (!_init) return;
      this.set('cmi.core.lesson_status', 'incomplete');
      this.set('cmi.core.exit', 'suspend');
      this.commit();
    }
  };
})();

